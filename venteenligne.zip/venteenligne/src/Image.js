import Img from "./image/avenger2.jpg"

function Image(){
    return(
    <div>
        <img src={Img} alt="Avengers"/>
        <p>Bacon ipsum dolor amet buffalo biltong pork kielbasa pig, ham hock andouille. Shankle tail shoulder, pork chop leberkas landjaeger bresaola short loin. Shoulder sausage ground round andouille. Leberkas ham tri-tip chuck turducken ribeye. Jerky cupim tail, flank pork loin chislic sirloin.</p>
    </div>
    );
}

export default Image;