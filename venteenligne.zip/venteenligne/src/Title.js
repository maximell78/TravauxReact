function Title() {
    return (
      <div>
          <h1>Bienvenue sur Vente en ligne</h1>
      </div>
    );
  }

  export default Title;