import prevision from "./MeteoData";

const cities = [
  {
    id: 1,
    name: "Paris",
    villeFavori: false,
    temperature: {prevision},
  },
  {
    id: 2,
    name: "Londres",
    villeFavori: false,
    //temperature: {prevision},
  },
  {
    id: 3,
    name: "New York",
    villeFavori: false,
    //temperature: {prevision},
  },
  {
    id: 4,
    name: "Belfast",
    villeFavori: false,
    //temperature: {prevision},
  },
  {
    id: 5,
    name: "Montreal",
    villeFavori: false,
    //temperature: {prevision},
  },
  {
    id: 6,
    name: "Toronto",
    villeFavori: false,
    //temperature: {prevision},
  },
  {
    id: 7,
    name: "Vancouver",
    villeFavori: false,
    //temperature: {prevision},
  },
  {
    id: 8,
    name: "San Francisco",
    villeFavori: false,
    //temperature: {prevision},
  },
  {
    id: 9,
    name: "Rome",
    villeFavori: false,
    //temperature: {prevision},
  },
  {
    id: 10,
    name: "Sydney",
    villeFavori: false,
    //temperature: {prevision},
  },
];
export default cities;