import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import Clock from "./components/Clock";

ReactDOM.render(<Clock />, document.getElementById("root"));
